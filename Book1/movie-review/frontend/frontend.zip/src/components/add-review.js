// Import React to use JSX
import React from 'react';

// Functional component for adding a movie review
function AddReview() {
  return (
    // Root container for the component
    <div className="App">
      {/* Placeholder text – will be replaced with a form later */}
      Add Review
    </div>
  );
}

// Export component so it can be used in routes or other components
export default AddReview;
