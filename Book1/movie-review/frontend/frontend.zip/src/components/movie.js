// Import React to enable JSX syntax
import React from 'react';

// Functional component to display a single movie's details
function Movie() {
  return (
    // Root container for the movie page
    <div className="App">
      {/* Placeholder content – movie details will go here */}
      Movie
    </div>
  );
}

// Export component so it can be used in routing
export default Movie;
