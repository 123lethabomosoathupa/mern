// Import React to enable JSX syntax
import React from 'react';

// Functional component for user login
function Login() {
  return (
    // Root container for the login page
    <div className="App">
      {/* Placeholder text – will be replaced with a login form */}
      Login
    </div>
  );
}

// Export component so it can be used in routing
export default Login;
