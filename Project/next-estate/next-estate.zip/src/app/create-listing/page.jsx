'use client';
import { useState } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';

export default function CreateListing() {
  const { data: session, status } = useSession();
  const [files, setFiles] = useState([]);
  const [uploading, setUploading] = useState(false);
  const [imageUploadError, setImageUploadError] = useState(false);
  const [error, setError] = useState(false);
  const [loading, setLoading] = useState(false);
  const router = useRouter();
  const [formData, setFormData] = useState({
    imageUrls: [], name: '', description: '', address: '',
    type: 'rent', bedrooms: 1, bathrooms: 1, regularPrice: 50,
    discountPrice: 0, offer: false, parking: false, furnished: false,
  });

  const handleImageSubmit = async (e) => {
    e.preventDefault();
    if (files.length === 0) { setImageUploadError('Please select at least one image'); return; }
    if (files.length + formData.imageUrls.length > 6) { setImageUploadError('You can only upload up to 6 images per listing'); return; }
    setUploading(true);
    setImageUploadError(false);
    try {
      const data = new FormData();
      Array.from(files).forEach((file) => data.append('files', file));
      const res = await fetch('/api/upload', { method: 'POST', body: data });
      const result = await res.json();
      if (!res.ok) throw new Error(result.error || 'Upload failed');
      setFormData((prev) => ({ ...prev, imageUrls: [...prev.imageUrls, ...result.urls] }));
      setFiles([]);
    } catch (err) {
      setImageUploadError(err.message || 'Image upload failed (2MB max)');
    } finally {
      setUploading(false);
    }
  };

  const handleRemoveImage = (index) => {
    setFormData({ ...formData, imageUrls: formData.imageUrls.filter((_, i) => i !== index) });
  };

  const handleChange = (e) => {
    if (e.target.id === 'sale' || e.target.id === 'rent') {
      setFormData({ ...formData, type: e.target.id });
    } else if (['parking', 'furnished', 'offer'].includes(e.target.id)) {
      setFormData({ ...formData, [e.target.id]: e.target.checked });
    } else if (['number', 'text', 'textarea'].includes(e.target.type)) {
      setFormData({ ...formData, [e.target.id]: e.target.value });
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (formData.imageUrls.length < 1) return setError('You must upload at least one image');
    if (+formData.regularPrice < +formData.discountPrice) return setError('Discount price must be lower than regular price');
    setLoading(true);
    setError(false);
    try {
      const res = await fetch('/api/listing/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });
      const data = await res.json();
      setLoading(false);
      if (data.success === false) { setError(data.message); return; }
      router.push(`/listing/${data._id}`);
    } catch (error) {
      setError(error.message);
      setLoading(false);
    }
  };

  if (status === 'loading') return <h1 className='text-center text-xl my-7 font-semibold'>Loading...</h1>;
  if (!session) return <h1 className='text-center text-xl my-7 font-semibold'>You must be signed in to create a listing. <a href='/sign-in' className='text-blue-600 underline'>Sign in</a></h1>;

  return (
    <main className='p-3 max-w-4xl mx-auto'>
      <h1 className='text-3xl font-semibold text-center my-7 text-gray-700'>Create a Listing</h1>
      <form className='flex flex-col sm:flex-row gap-4' onSubmit={handleSubmit}>
        <div className='flex flex-col gap-4 flex-1'>
          <input type='text' placeholder='Name' className='border border-gray-300 p-3 rounded-lg text-gray-800 bg-white' id='name' maxLength='62' minLength='10' required onChange={handleChange} value={formData.name} />
          <textarea placeholder='Description' className='border border-gray-300 p-3 rounded-lg text-gray-800 bg-white' id='description' required onChange={handleChange} value={formData.description} />
          <input type='text' placeholder='Address' className='border border-gray-300 p-3 rounded-lg text-gray-800 bg-white' id='address' required onChange={handleChange} value={formData.address} />
          <div className='flex gap-6 flex-wrap'>
            <div className='flex gap-2'><input type='checkbox' id='sale' className='w-5' onChange={handleChange} checked={formData.type === 'sale'} /><span className='text-gray-700'>Sell</span></div>
            <div className='flex gap-2'><input type='checkbox' id='rent' className='w-5' onChange={handleChange} checked={formData.type === 'rent'} /><span className='text-gray-700'>Rent</span></div>
            <div className='flex gap-2'><input type='checkbox' id='parking' className='w-5' onChange={handleChange} checked={formData.parking} /><span className='text-gray-700'>Parking spot</span></div>
            <div className='flex gap-2'><input type='checkbox' id='furnished' className='w-5' onChange={handleChange} checked={formData.furnished} /><span className='text-gray-700'>Furnished</span></div>
            <div className='flex gap-2'><input type='checkbox' id='offer' className='w-5' onChange={handleChange} checked={formData.offer} /><span className='text-gray-700'>Offer</span></div>
          </div>
          <div className='flex flex-wrap gap-6'>
            <div className='flex items-center gap-2'><input type='number' id='bedrooms' min='1' max='10' required className='p-3 border border-gray-300 rounded-lg text-gray-800 bg-white w-20' onChange={handleChange} value={formData.bedrooms} /><p className='text-gray-700'>Beds</p></div>
            <div className='flex items-center gap-2'><input type='number' id='bathrooms' min='1' max='10' required className='p-3 border border-gray-300 rounded-lg text-gray-800 bg-white w-20' onChange={handleChange} value={formData.bathrooms} /><p className='text-gray-700'>Baths</p></div>
            <div className='flex items-center gap-2'><input type='number' id='regularPrice' min='50' max='10000000' required className='p-3 border border-gray-300 rounded-lg text-gray-800 bg-white w-32' onChange={handleChange} value={formData.regularPrice} /><div className='flex flex-col items-center'><p className='text-gray-700'>Regular price</p><span className='text-xs text-gray-500'>( R / month)</span></div></div>
            {formData.offer && (<div className='flex items-center gap-2'><input type='number' id='discountPrice' min='0' max='10000000' required className='p-3 border border-gray-300 rounded-lg text-gray-800 bg-white w-32' onChange={handleChange} value={formData.discountPrice} /><div className='flex flex-col items-center'><p className='text-gray-700'>Discounted price</p><span className='text-xs text-gray-500'>( R / month)</span></div></div>)}
          </div>
        </div>
        <div className='flex flex-col flex-1 gap-4'>
          <p className='font-semibold text-gray-700'>Images:<span className='font-normal text-gray-500 ml-2'>The first image will be the cover (max 6)</span></p>
          <div className='flex gap-4'>
            <input className='p-3 border border-gray-300 rounded w-full text-gray-700 bg-white' type='file' id='images' accept='image/*' multiple onChange={(e) => setFiles(e.target.files)} />
            <button type='button' disabled={uploading} onClick={handleImageSubmit} className='p-3 text-green-700 border border-green-700 rounded uppercase hover:shadow-lg disabled:opacity-80'>{uploading ? 'Uploading...' : 'Upload'}</button>
          </div>
          {imageUploadError && <p className='text-red-700 text-sm'>{imageUploadError}</p>}
          {formData.imageUrls.map((url, index) => (
            <div key={url} className='flex justify-between p-3 border border-gray-200 items-center rounded-lg'>
              <img src={url} alt='listing image' className='w-20 h-20 object-contain rounded-lg' />
              <button type='button' onClick={() => handleRemoveImage(index)} className='p-3 text-red-700 rounded-lg uppercase hover:opacity-75'>Delete</button>
            </div>
          ))}
          <button className='p-3 bg-gray-700 text-white rounded-lg uppercase hover:bg-gray-600 disabled:opacity-80' disabled={loading || uploading}>{loading ? 'Creating...' : 'Create Listing'}</button>
          {error && <p className='text-red-700 text-sm'>{error}</p>}
        </div>
      </form>
    </main>
  );
}
