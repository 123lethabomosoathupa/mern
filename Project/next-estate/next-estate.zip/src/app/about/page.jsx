export default function About() {
  return (
    <div className='min-h-screen bg-gray-100'>
      <div className='py-16 px-4 max-w-4xl mx-auto'>
        <h1 className='text-3xl font-bold mb-6 text-gray-700'>About Sahand Estate</h1>
        <div className='bg-white rounded-xl shadow-sm border border-gray-200 p-8 flex flex-col gap-4'>
          <p className='text-gray-600 leading-relaxed'>Sahand Estate is a leading real estate agency that specializes in helping clients buy, sell, and rent properties in the most desirable neighborhoods. Our team of experienced agents is dedicated to providing exceptional service and making the buying and selling process as smooth as possible.</p>
          <p className='text-gray-600 leading-relaxed'>Our mission is to help our clients achieve their real estate goals by providing expert advice, personalized service, and a deep understanding of the local market. Whether you are looking to buy, sell, or rent a property, we are here to help you every step of the way.</p>
          <p className='text-gray-600 leading-relaxed'>Our team of agents has a wealth of experience and knowledge in the real estate industry, and we are committed to providing the highest level of service to our clients. We believe that buying or selling a property should be an exciting and rewarding experience.</p>
        </div>
      </div>
    </div>
  );
}
